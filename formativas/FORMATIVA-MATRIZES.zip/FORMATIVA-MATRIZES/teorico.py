import numpy as np

A = ([[1,2],
      [3,4]])

B = ([[0,1],
      [-1,0]])

R = np.dot(A,B)

print(f"Resposta 1): numpy. \n \n Resposta 2): np.eye(3) \n \n Resposta 3): np.dot(). \n \n Resposta 4): np.transpose() \n \n Resposta 5): \n {R}, \n letra D.")

